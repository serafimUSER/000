let status = 0;
let status_lang = false;
let last_title;

let window_statis = false;
let window_id = -1;
let window_id_local = -1

let data_loc = {};

const labels = {
    by: ["Помнікі", "Музеі", "Мемарыялы"],
    ru: ["Памятники", "Музеи", "Мемориалы"]
};


document.getElementById("close").onclick = function() {
    window_statis = false
    
    let window = document.getElementById("windowContent")
    window.classList.add('unactive')
}

function linkWindow(title, text, src_, key){
    if (!window_statis){
        let window = document.getElementById("windowContent")
        let title__window = document.getElementById('title__window')
        let text_window = document.getElementById('text_window')
        
        document.getElementById('img_window').src = src_
        window_id_local = key

        last_title = title
        title__window.textContent = title
        text_window.textContent = text

        window.classList.remove('unactive')
        window_statis = true;
    }
}

document.getElementById('route').onclick = function () {
    let location = data_loc[last_title]
    let lat = location[0]
    let lon = location[1]


    window.location.href = `/route/?lat=${lat}&lon=${lon}&key_global=${window_id}&key_local=${window_id_local}`
}

document.getElementById('Lang').onclick = function() {
    ButtonActive(status)
    if (status_lang){
        ButtonUnActiveLang();
        status_lang = false;
        return;
    }
    setTimeout(function() {
        document.getElementById('Lang').style.backgroundColor = "#E8ECF1"
        document.getElementById('ImgLang').src = '../img/black/black_lang.svg';
    }, 50)
    status_lang = true;
}

function ButtonUnActiveLang() {
    setTimeout(function() {
        document.getElementById('Lang').style.backgroundColor = "#587a86"
        document.getElementById('ImgLang').src = '../img/active/lang.svg';
    }, 50)
}

function Render(data) {
    let htmlData = ``;
    

    for (const key in data) {
        if (data.hasOwnProperty(key)) {
          const item = data[key];
          
          let text = item.text
          let maxLength = 155
          
          if (text.length > maxLength) {
            text = text.substring(0, maxLength)
            text += "..."
          }

          htmlData += `
          <a href="#" onclick="linkWindow('${item.title}', '${item.text}', '${item.src}', ${key})">
            <div class="crad__info">
                <div class="image" style="background: url('${item.src}'); background-size: cover;">
                </div>
                <div class="descript">
                    <h3>${item.title}</h3>
                    <p>${text}</p>
                </div>
            </div>
        </a>`
          let mark = L.marker(item.loc, {icon: Icon}).addTo(map);
          mark.bindTooltip("<b>" + item.title + "</b>")
          data_loc[item.title] = item.loc
        }
      }
    document.getElementById('render').innerHTML = htmlData;
}

function ButtonActive(id){
    if (status != 0 && status != id) {
        ButtonUnActive(status);
    }

    status = id;
    let renderData;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'js/json/data.json', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var data = JSON.parse(xhr.responseText);
            let column = document.getElementById("column");

            let data_lang = {
                1: { by: data.mon, ru: data.mon_ru },
                2: { by: data.mus, ru: data.mus_ru },
                3: { by: data.oth, ru: data.oth_ru }
            };
            if (!status_lang) {
                renderData = data_lang[id].by;
                column.textContent = labels.by[id - 1];
            } else {
                renderData = data_lang[id].ru;
                column.textContent = labels.ru[id - 1];
            }
            window_id = id
            Render(renderData)
        }
    };
    xhr.send();

    let srcs = ["../img/black/black_monuments.svg", "../img/black/black_musiem.svg", "../img/black/black_others.svg"]
    setTimeout(function() {
        document.getElementById('ButtonActive' + id).style.backgroundColor = "#E8ECF1";
        document.getElementById('Img' + id).src = srcs[id-1];
    }, 50); 
}

function ButtonUnActive(id){
    let srcs = ["../img/active/monuments.svg", "../img/active/musiem.svg", "../img/active/others.svg"]

    document.getElementById('ButtonActive' + id).style.backgroundColor = "#587a86";
    document.getElementById('Img' + id).src = srcs[id-1];
}


